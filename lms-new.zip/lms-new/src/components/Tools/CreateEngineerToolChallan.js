import { Button } from '@mui/material';
import React, { useState } from 'react'
import secureLocalStorage from 'react-secure-storage';
import AddProductEngineerModal from './AddProductEngineerModal';

const CreateEngineerToolChallan = () => {
      const [modal, setModal] = useState(false);
      const { data: userData } = JSON.parse(secureLocalStorage.getItem("info"));
  return (
    <div>
   <div className="flex justify-center my-2">
        <Button variant="contained" onClick={() => setModal(true)}>
          Add Product To Challan
        </Button>
      </div>
 <AddProductEngineerModal modal={modal} setModal={setModal} />  
    </div>
  )
}

export default CreateEngineerToolChallan;