export const companiesDetails = [
  {
    name: "Pes Electricals Pvt.Ltd",
    address: "1",
    gstIn: "1",
    phoneNumber: "1",
  },
  {
    name: "Pes Online Services",
    address: "2",
    gstIn: "2",
    phoneNumber: "2",
  },
  {
    name: "Perfect Engineering Services",
    address: "3",
    gstIn: "3",
    phoneNumber: "3",
  },
];
