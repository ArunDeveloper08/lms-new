import React from "react";
import DealerComponent from "./DealerComponent";
import { Box } from "@mui/material";

const Dealer = () => {
  return (
    <Box>
      <DealerComponent />
    </Box>
  );
};

export default Dealer;
