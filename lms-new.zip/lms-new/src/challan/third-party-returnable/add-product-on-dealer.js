import React from "react";

const AddProductOnDealer = () => {
  return <div>AddProductOnDealer</div>;
};

export default AddProductOnDealer;
