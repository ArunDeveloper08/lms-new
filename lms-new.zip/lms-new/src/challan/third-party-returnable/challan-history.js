import React from 'react';

const ChallanHistory = () => {
    return (
        <div>ThirdPartyChallanHistory</div>
    );
};

export default ChallanHistory;